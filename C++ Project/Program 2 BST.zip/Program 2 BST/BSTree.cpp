#include "BSTree.h"

Node*  BSTree::getNode(const string &word){
      Node* temp = root;
      while(temp->word != word){
            if(word < temp->word)
                  temp = temp->left;
            else
                  temp = temp->right;
      }
      return temp;
}

Node* BSTree::getParent(const string& word){
      //word should never be root
      Node* temp = root;
      while(temp != nullptr){
            if(word < temp->word){
                  if(temp->left->word == word)
                        return temp;
                  temp = temp->left;
            }
            else{
                  if(temp->right->word == word)
                        return temp;
                  temp = temp->right;
            }
      }
      cout << "Unreachable line is reached in getParent()" << endl;
      return temp; //This line should never reach

}

Node* BSTree::left_successor(Node* node){
      if(node == nullptr)
            return nullptr;
      if(node->right == nullptr)
            return node;
      return left_successor(node->right);
}

Node* BSTree::right_successor(Node* node){
      if(node == nullptr)
            return nullptr;
      if(node->left == nullptr)
            return node;
      return right_successor(node->left);
}

Node* BSTree::successor(Node* node){
      Node* leftsuccessor = left_successor(node->left);
      Node* rightsuccessor = right_successor(node->right);

      if(leftsuccessor != nullptr)
            return leftsuccessor;
      if(rightsuccessor != nullptr)
            return rightsuccessor;

      return nullptr;
}

bool BSTree::isleftsibling(Node* parent, Node* kid){
      return parent->left == kid;
}

void BSTree::insert(const string & word){
      if(root == nullptr){
            root = new Node(word, 1);
            return;
      }
      //Increment count if word already exist
      if(search(word)){
            Node* temp = getNode(word);
            temp->count = temp->count + 1;
            return;
      }

      Node* temp = root;
      while(temp != nullptr){
            if(word < temp->word){
                  if(temp->left == nullptr){
                        temp->left = new Node(word, 1);
                        return;
                  }
                  else
                        temp = temp->left;
            }
            else{
                  if(temp->right == nullptr){
                        temp->right = new Node(word,1);
                        return;
                  }
                  else
                        temp = temp->right;
            }
      }
}

bool BSTree::search(const string &word) const{
      if(root == nullptr)
            return false;

      Node* temp = root;
      while(temp != nullptr){
            if(temp->word == word)
                  return true;
            if(word < temp->word)
                  temp = temp->left;
            else
                  temp = temp->right;
      }
      return false;
}

string BSTree::largest() const{
      Node* temp = root;
      while(temp != nullptr){
            if(temp->right == nullptr)
                  return temp->word;
            temp = temp->right;
      }
      return "";
}

string BSTree::smallest() const{
      Node* temp = root;
      while(temp!= nullptr){
            if(temp->left == nullptr)
                  return temp->word;
            temp = temp->left;
      }
      return "";
}

int BSTree::height(const string &word) const{
      if(root == nullptr || !search(word))
            return -1;
      int count = 0;
      Node* temp = root;
      while(temp != nullptr){
            if(temp->word == word)
                  return count;
            if(word < temp->word)
                  temp = temp->left;
            else
                  temp = temp->right;
            count++;
      }
      return -1; //Will never reach
}

void BSTree::remove(const string& word){
      //Exit if word doesnt exist
      if(!search(word))
            return;

      Node* toRemove = getNode(word);

      //Decrease count if count > 1
      if(toRemove->count > 1){
            toRemove->count = toRemove->count - 1;
            return;
      }
      //If toRemove is leaf node, kill it
      if(successor(toRemove) == nullptr){
            //Root case
            if(toRemove == root){
                  root = nullptr;
                  delete toRemove;
                  return;
            }
            //toRemove must have parent - all other case
            Node* parent = getParent(word);
            if(isleftsibling(parent,toRemove)){
                  parent->left = nullptr;
                  return;
            }
            parent->right = nullptr;
            return;
      }

      //One child case
      if(toRemove->left == nullptr){
            if(toRemove == root){
                  root = toRemove->right;
                  delete toRemove;
                  return;
            }

      }



}
