#ifndef __BSTREE_H__
#define __BSTREE_H__

#include "Node.h"

using namespace std;

class BSTree {

private:
  Node *root;

private:
  void preOrder(Node *) const;
  Node* getNode(const string &); //Done
  Node* getParent(const string&); //Done
  bool isleftsibling(Node* parent, Node* kid); //Done
  Node* successor(Node* node); //Done
  Node* left_successor(Node* node); //Done
  Node* right_successor(Node* node); //Done

public:
  void insert(const string &);      //Done
  bool search(const string &) const; //Done
  void inOrder( ) const;
  void postOrder( ) const;
  void preOrder( ) const;
  string largest( ) const; //Done
  string smallest( ) const; //Done
  int height(const string &) const; //Done
  void remove(const string &);
};

#endif
