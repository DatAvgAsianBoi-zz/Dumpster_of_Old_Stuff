#include "Node.h"


Node::Node(string w, int c): word(w), count(c), left(nullptr), right(nullptr){};
